Select c.Name,
 c.Email,
o.OrderDate,
od.OrderedQuantity,
p.Name productName,
p.Price Unit_Price
  from Customer c
full outer join Orders o on o.CustomerId = c.Id 
full outer join OrderDetail od on od.OrderId = o.Id 
full outer join Product p on p.Id = od.ProductId
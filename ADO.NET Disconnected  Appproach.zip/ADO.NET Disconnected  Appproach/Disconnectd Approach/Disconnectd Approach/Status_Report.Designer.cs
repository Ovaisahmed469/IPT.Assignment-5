﻿namespace Disconnectd_Approach
{
    partial class Status_Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.OrderManagmentSystemDataSet1 = new Disconnectd_Approach.OrderManagmentSystemDataSet1();
            this.Status_ReportBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Status_ReportTableAdapter = new Disconnectd_Approach.OrderManagmentSystemDataSet1TableAdapters.Status_ReportTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.OrderManagmentSystemDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_ReportBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.Status_ReportBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Disconnectd_Approach.Status_wise_Report.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(12, 12);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(1135, 496);
            this.reportViewer1.TabIndex = 0;
            // 
            // OrderManagmentSystemDataSet1
            // 
            this.OrderManagmentSystemDataSet1.DataSetName = "OrderManagmentSystemDataSet1";
            this.OrderManagmentSystemDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // Status_ReportBindingSource
            // 
            this.Status_ReportBindingSource.DataMember = "Status_Report";
            this.Status_ReportBindingSource.DataSource = this.OrderManagmentSystemDataSet1;
            // 
            // Status_ReportTableAdapter
            // 
            this.Status_ReportTableAdapter.ClearBeforeFill = true;
            // 
            // Status_Report
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1159, 520);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Status_Report";
            this.Text = "Status_Report";
            this.Load += new System.EventHandler(this.Status_Report_Load);
            ((System.ComponentModel.ISupportInitialize)(this.OrderManagmentSystemDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_ReportBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource Status_ReportBindingSource;
        private OrderManagmentSystemDataSet1 OrderManagmentSystemDataSet1;
        private OrderManagmentSystemDataSet1TableAdapters.Status_ReportTableAdapter Status_ReportTableAdapter;
    }
}
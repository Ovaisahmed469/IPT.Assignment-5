﻿namespace Disconnectd_Approach
{
    partial class Order_Detail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Deletebutton = new System.Windows.Forms.Button();
            this.Updatebutton = new System.Windows.Forms.Button();
            this.txtbuttnaddcustomer = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel_addorder_detail = new System.Windows.Forms.Panel();
            this.txtOrderedQuatity = new System.Windows.Forms.TextBox();
            this.txtProductId = new System.Windows.Forms.TextBox();
            this.txtOrderId = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ProductId = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.adddetailbutton = new System.Windows.Forms.Button();
            this.Resetbutton = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.panel_updateorderdetail = new System.Windows.Forms.Panel();
            this.txtorderquantity_update = new System.Windows.Forms.TextBox();
            this.txtproductId_update = new System.Windows.Forms.TextBox();
            this.txtorderId_update = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.OrderDetail_List = new System.Windows.Forms.ListBox();
            this.orderdetail_updatebutton = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel_deleteorderdetail = new System.Windows.Forms.Panel();
            this.button2Cancelbutton = new System.Windows.Forms.Button();
            this.button1Deletebutton = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.cbOrder_Detail = new System.Windows.Forms.ComboBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel_addorder_detail.SuspendLayout();
            this.panel_updateorderdetail.SuspendLayout();
            this.panel_deleteorderdetail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.SuspendLayout();
            // 
            // Deletebutton
            // 
            this.Deletebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebutton.Location = new System.Drawing.Point(394, 12);
            this.Deletebutton.Name = "Deletebutton";
            this.Deletebutton.Size = new System.Drawing.Size(195, 47);
            this.Deletebutton.TabIndex = 11;
            this.Deletebutton.Text = "Delete";
            this.Deletebutton.UseVisualStyleBackColor = true;
            this.Deletebutton.Click += new System.EventHandler(this.Deletebutton_Click);
            // 
            // Updatebutton
            // 
            this.Updatebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebutton.Location = new System.Drawing.Point(187, 12);
            this.Updatebutton.Name = "Updatebutton";
            this.Updatebutton.Size = new System.Drawing.Size(181, 46);
            this.Updatebutton.TabIndex = 10;
            this.Updatebutton.Text = "Update";
            this.Updatebutton.UseVisualStyleBackColor = true;
            this.Updatebutton.Click += new System.EventHandler(this.Updatebutton_Click);
            // 
            // txtbuttnaddcustomer
            // 
            this.txtbuttnaddcustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbuttnaddcustomer.Location = new System.Drawing.Point(30, 12);
            this.txtbuttnaddcustomer.Name = "txtbuttnaddcustomer";
            this.txtbuttnaddcustomer.Size = new System.Drawing.Size(151, 47);
            this.txtbuttnaddcustomer.TabIndex = 9;
            this.txtbuttnaddcustomer.Text = "Add";
            this.txtbuttnaddcustomer.UseVisualStyleBackColor = true;
            this.txtbuttnaddcustomer.Click += new System.EventHandler(this.txtbuttnaddcustomer_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(26, 456);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(338, 136);
            this.dataGridView1.TabIndex = 12;
            // 
            // panel_addorder_detail
            // 
            this.panel_addorder_detail.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.panel_addorder_detail.Controls.Add(this.adddetailbutton);
            this.panel_addorder_detail.Controls.Add(this.Resetbutton);
            this.panel_addorder_detail.Controls.Add(this.buttonCancel);
            this.panel_addorder_detail.Controls.Add(this.txtOrderedQuatity);
            this.panel_addorder_detail.Controls.Add(this.txtProductId);
            this.panel_addorder_detail.Controls.Add(this.txtOrderId);
            this.panel_addorder_detail.Controls.Add(this.label3);
            this.panel_addorder_detail.Controls.Add(this.ProductId);
            this.panel_addorder_detail.Controls.Add(this.label1);
            this.panel_addorder_detail.Location = new System.Drawing.Point(30, 78);
            this.panel_addorder_detail.Name = "panel_addorder_detail";
            this.panel_addorder_detail.Size = new System.Drawing.Size(672, 297);
            this.panel_addorder_detail.TabIndex = 13;
            this.panel_addorder_detail.Visible = false;
            // 
            // txtOrderedQuatity
            // 
            this.txtOrderedQuatity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrderedQuatity.Location = new System.Drawing.Point(209, 142);
            this.txtOrderedQuatity.Name = "txtOrderedQuatity";
            this.txtOrderedQuatity.Size = new System.Drawing.Size(266, 31);
            this.txtOrderedQuatity.TabIndex = 6;
            // 
            // txtProductId
            // 
            this.txtProductId.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductId.Location = new System.Drawing.Point(209, 82);
            this.txtProductId.Name = "txtProductId";
            this.txtProductId.Size = new System.Drawing.Size(266, 31);
            this.txtProductId.TabIndex = 7;
            // 
            // txtOrderId
            // 
            this.txtOrderId.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOrderId.Location = new System.Drawing.Point(209, 16);
            this.txtOrderId.Name = "txtOrderId";
            this.txtOrderId.Size = new System.Drawing.Size(266, 31);
            this.txtOrderId.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(198, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "Ordered_Quantity";
            // 
            // ProductId
            // 
            this.ProductId.AutoSize = true;
            this.ProductId.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProductId.Location = new System.Drawing.Point(33, 85);
            this.ProductId.Name = "ProductId";
            this.ProductId.Size = new System.Drawing.Size(125, 25);
            this.ProductId.TabIndex = 4;
            this.ProductId.Text = "Product_Id";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(33, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Order_Id";
            // 
            // adddetailbutton
            // 
            this.adddetailbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adddetailbutton.Location = new System.Drawing.Point(247, 210);
            this.adddetailbutton.Name = "adddetailbutton";
            this.adddetailbutton.Size = new System.Drawing.Size(114, 39);
            this.adddetailbutton.TabIndex = 29;
            this.adddetailbutton.Text = "Add";
            this.adddetailbutton.UseVisualStyleBackColor = true;
            this.adddetailbutton.Click += new System.EventHandler(this.adddetailbutton_Click);
            // 
            // Resetbutton
            // 
            this.Resetbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Resetbutton.Location = new System.Drawing.Point(122, 237);
            this.Resetbutton.Name = "Resetbutton";
            this.Resetbutton.Size = new System.Drawing.Size(99, 24);
            this.Resetbutton.TabIndex = 28;
            this.Resetbutton.Text = "Reset All Box";
            this.Resetbutton.UseVisualStyleBackColor = true;
            this.Resetbutton.Click += new System.EventHandler(this.Resetbutton_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCancel.Location = new System.Drawing.Point(122, 206);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(99, 24);
            this.buttonCancel.TabIndex = 27;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // panel_updateorderdetail
            // 
            this.panel_updateorderdetail.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel_updateorderdetail.Controls.Add(this.orderdetail_updatebutton);
            this.panel_updateorderdetail.Controls.Add(this.button1);
            this.panel_updateorderdetail.Controls.Add(this.button2);
            this.panel_updateorderdetail.Controls.Add(this.OrderDetail_List);
            this.panel_updateorderdetail.Controls.Add(this.txtorderquantity_update);
            this.panel_updateorderdetail.Controls.Add(this.txtproductId_update);
            this.panel_updateorderdetail.Controls.Add(this.txtorderId_update);
            this.panel_updateorderdetail.Controls.Add(this.label2);
            this.panel_updateorderdetail.Controls.Add(this.label4);
            this.panel_updateorderdetail.Controls.Add(this.label5);
            this.panel_updateorderdetail.Location = new System.Drawing.Point(40, 78);
            this.panel_updateorderdetail.Name = "panel_updateorderdetail";
            this.panel_updateorderdetail.Size = new System.Drawing.Size(791, 317);
            this.panel_updateorderdetail.TabIndex = 30;
            this.panel_updateorderdetail.Visible = false;
            this.panel_updateorderdetail.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_updateorderdetail_Paint);
            // 
            // txtorderquantity_update
            // 
            this.txtorderquantity_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtorderquantity_update.Location = new System.Drawing.Point(453, 145);
            this.txtorderquantity_update.Name = "txtorderquantity_update";
            this.txtorderquantity_update.Size = new System.Drawing.Size(266, 31);
            this.txtorderquantity_update.TabIndex = 6;
            // 
            // txtproductId_update
            // 
            this.txtproductId_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtproductId_update.Location = new System.Drawing.Point(453, 82);
            this.txtproductId_update.Name = "txtproductId_update";
            this.txtproductId_update.Size = new System.Drawing.Size(266, 31);
            this.txtproductId_update.TabIndex = 7;
            // 
            // txtorderId_update
            // 
            this.txtorderId_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtorderId_update.Location = new System.Drawing.Point(453, 25);
            this.txtorderId_update.Name = "txtorderId_update";
            this.txtorderId_update.Size = new System.Drawing.Size(266, 31);
            this.txtorderId_update.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(244, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(198, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Ordered_Quantity";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(277, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 25);
            this.label4.TabIndex = 4;
            this.label4.Text = "Product_Id";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(277, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(103, 25);
            this.label5.TabIndex = 5;
            this.label5.Text = "Order_Id";
            // 
            // OrderDetail_List
            // 
            this.OrderDetail_List.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderDetail_List.FormattingEnabled = true;
            this.OrderDetail_List.ItemHeight = 31;
            this.OrderDetail_List.Location = new System.Drawing.Point(14, 11);
            this.OrderDetail_List.Name = "OrderDetail_List";
            this.OrderDetail_List.Size = new System.Drawing.Size(224, 283);
            this.OrderDetail_List.TabIndex = 28;
            this.OrderDetail_List.Click += new System.EventHandler(this.OrderDetail_List_Click);
            // 
            // orderdetail_updatebutton
            // 
            this.orderdetail_updatebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderdetail_updatebutton.Location = new System.Drawing.Point(464, 222);
            this.orderdetail_updatebutton.Name = "orderdetail_updatebutton";
            this.orderdetail_updatebutton.Size = new System.Drawing.Size(114, 39);
            this.orderdetail_updatebutton.TabIndex = 31;
            this.orderdetail_updatebutton.Text = "Update";
            this.orderdetail_updatebutton.UseVisualStyleBackColor = true;
            this.orderdetail_updatebutton.Click += new System.EventHandler(this.orderdetail_updatebutton_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(339, 249);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 24);
            this.button1.TabIndex = 30;
            this.button1.Text = "Reset All Box";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(339, 218);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(99, 24);
            this.button2.TabIndex = 29;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel_deleteorderdetail
            // 
            this.panel_deleteorderdetail.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel_deleteorderdetail.Controls.Add(this.button2Cancelbutton);
            this.panel_deleteorderdetail.Controls.Add(this.button1Deletebutton);
            this.panel_deleteorderdetail.Controls.Add(this.label11);
            this.panel_deleteorderdetail.Controls.Add(this.cbOrder_Detail);
            this.panel_deleteorderdetail.Location = new System.Drawing.Point(30, 65);
            this.panel_deleteorderdetail.Name = "panel_deleteorderdetail";
            this.panel_deleteorderdetail.Size = new System.Drawing.Size(588, 330);
            this.panel_deleteorderdetail.TabIndex = 32;
            this.panel_deleteorderdetail.Visible = false;
            // 
            // button2Cancelbutton
            // 
            this.button2Cancelbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2Cancelbutton.Location = new System.Drawing.Point(346, 200);
            this.button2Cancelbutton.Name = "button2Cancelbutton";
            this.button2Cancelbutton.Size = new System.Drawing.Size(102, 43);
            this.button2Cancelbutton.TabIndex = 7;
            this.button2Cancelbutton.Text = "Cancel";
            this.button2Cancelbutton.UseVisualStyleBackColor = true;
            this.button2Cancelbutton.Click += new System.EventHandler(this.button2Cancelbutton_Click);
            // 
            // button1Deletebutton
            // 
            this.button1Deletebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1Deletebutton.Location = new System.Drawing.Point(149, 202);
            this.button1Deletebutton.Name = "button1Deletebutton";
            this.button1Deletebutton.Size = new System.Drawing.Size(96, 41);
            this.button1Deletebutton.TabIndex = 6;
            this.button1Deletebutton.Text = "Delete";
            this.button1Deletebutton.UseVisualStyleBackColor = true;
            this.button1Deletebutton.Click += new System.EventHandler(this.button1Deletebutton_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(85, 63);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(446, 20);
            this.label11.TabIndex = 5;
            this.label11.Text = "Choose The Order Details which   you want to remove.!";
            // 
            // cbOrder_Detail
            // 
            this.cbOrder_Detail.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbOrder_Detail.FormattingEnabled = true;
            this.cbOrder_Detail.Location = new System.Drawing.Point(149, 98);
            this.cbOrder_Detail.Name = "cbOrder_Detail";
            this.cbOrder_Detail.Size = new System.Drawing.Size(299, 37);
            this.cbOrder_Detail.TabIndex = 4;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(375, 460);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(327, 132);
            this.dataGridView2.TabIndex = 33;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(717, 462);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(289, 130);
            this.dataGridView3.TabIndex = 34;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(434, 428);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 20);
            this.label6.TabIndex = 35;
            this.label6.Text = "Orders Table";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(742, 428);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 20);
            this.label7.TabIndex = 35;
            this.label7.Text = "products Table";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(106, 428);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(169, 20);
            this.label8.TabIndex = 35;
            this.label8.Text = "Order_Details Table";
            // 
            // Order_Detail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(1203, 604);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.panel_deleteorderdetail);
            this.Controls.Add(this.panel_updateorderdetail);
            this.Controls.Add(this.panel_addorder_detail);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Deletebutton);
            this.Controls.Add(this.Updatebutton);
            this.Controls.Add(this.txtbuttnaddcustomer);
            this.Name = "Order_Detail";
            this.Text = "Order_Detail";
            this.Load += new System.EventHandler(this.Order_Detail_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel_addorder_detail.ResumeLayout(false);
            this.panel_addorder_detail.PerformLayout();
            this.panel_updateorderdetail.ResumeLayout(false);
            this.panel_updateorderdetail.PerformLayout();
            this.panel_deleteorderdetail.ResumeLayout(false);
            this.panel_deleteorderdetail.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Deletebutton;
        private System.Windows.Forms.Button Updatebutton;
        private System.Windows.Forms.Button txtbuttnaddcustomer;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel_addorder_detail;
        private System.Windows.Forms.TextBox txtOrderedQuatity;
        private System.Windows.Forms.TextBox txtProductId;
        private System.Windows.Forms.TextBox txtOrderId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label ProductId;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button adddetailbutton;
        private System.Windows.Forms.Button Resetbutton;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Panel panel_updateorderdetail;
        private System.Windows.Forms.TextBox txtorderquantity_update;
        private System.Windows.Forms.TextBox txtproductId_update;
        private System.Windows.Forms.TextBox txtorderId_update;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ListBox OrderDetail_List;
        private System.Windows.Forms.Button orderdetail_updatebutton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel_deleteorderdetail;
        private System.Windows.Forms.Button button2Cancelbutton;
        private System.Windows.Forms.Button button1Deletebutton;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbOrder_Detail;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Disconnectd_Approach
{
    public partial class Reporting : Form
    {
        public Reporting()
        {
            InitializeComponent();
        }

        private void Reporting_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'OrderManagmentSystemDataSet.Allorders' table. You can move, or remove it, as needed.
            this.AllordersTableAdapter.Fill(this.OrderManagmentSystemDataSet.Allorders);

            this.reportViewer1.RefreshReport();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Disconnectd_Approach
{
    public partial class Order_status : Form
    {
        public Order_status()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-B77S1AJ;Initial Catalog=OrderManagmentSystem;Integrated Security=True");

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtorderid_update_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Order_status_Load(object sender, EventArgs e)
        {
            Refreshgridview();
        }

        private void Refreshgridview()
        {
            DataSet ds = new DataSet();
            SqlDataAdapter adpt = new SqlDataAdapter("Select * from Order_Details", conn);
            adpt.Fill(ds, "Order_Details");
            dataGridView1.DataSource = ds.Tables["Order_Details"];


            DataSet dt = new DataSet();
            SqlDataAdapter adpato = new SqlDataAdapter("Select * from Orders", conn);

            adpato.Fill(dt, "Orders");
            dataGridView2.DataSource = dt.Tables["Orders"];

            DataSet dd = new DataSet();
            SqlDataAdapter apt = new SqlDataAdapter("Select * from Product", conn);
            apt.Fill(dd, "Product");
            dataGridView3.DataSource = dd.Tables["Product"];


            DataSet de = new DataSet();
            SqlDataAdapter aapt = new SqlDataAdapter("Select * from Order_status", conn);
            aapt.Fill(de, "Order_status");


            O_status_list.DataSource = de.Tables["Order_status"];
            O_status_list.DisplayMember = "Order_status_id";
            O_status_list.ValueMember = "Order_status_id";

            o_status_comboBox.DataSource = de.Tables["Order_status"];
            o_status_comboBox.DisplayMember = "Order_status_id";
            o_status_comboBox.ValueMember = "Order_status_id";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void deletebutton_Click(object sender, EventArgs e)
        {

            try
            {


                if (MessageBox.Show("Are you Sure!", "Confirm", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    var ds = new DataSet();
                    var adpt = new SqlDataAdapter("Select * from Order_status where Order_status_id=" + o_status_comboBox.SelectedValue, conn);
                    adpt.Fill(ds, "Order_status");

                    foreach (DataRow dr in ds.Tables["Order_status"].Rows)
                    {
                        dr.Delete();
                    }

                    var buil = new SqlCommandBuilder(adpt);
                    adpt.Update(ds, "Order_status");

                    Refreshgridview();
                    MessageBox.Show("Order_status  Deleted Successfully");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void addorderstatus_Click(object sender, EventArgs e)
        {

            try
            {
                var ds = new DataSet();
                var adpt = new SqlDataAdapter("Select * from Order_status", conn);
                adpt.Fill(ds, "Order_status");

                DataRow dr = ds.Tables["Order_status"].NewRow();


                dr["Order_id"] = txtorderid.Text;
                dr["Product_id"] = txtproductId.Text;

                ds.Tables["Order_status"].Rows.Add(dr);

                var buil = new SqlCommandBuilder(adpt);
                adpt.Update(ds, "Order_status");


                Refreshgridview();
                txtproductId.Text = txtorderid.Text = "";
                MessageBox.Show("Order_status Added Successfully");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtproductId_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            try
            {
              

                var ds = new DataSet();
                var adpt = new SqlDataAdapter("Select * from Order_status where Order_status_id=" + O_status_list.SelectedValue, conn);
                adpt.Fill(ds, "Order_status");

                foreach (DataRow dr in ds.Tables["Order_status"].Rows)
                {

                    dr["Order_id"] = txtorderid_update.Text;
                    dr["Product_id"] = txtProductId_Update.Text;

                }

                var buil = new SqlCommandBuilder(adpt);
                adpt.Update(ds, "Order_status");

                Refreshgridview();
              
                MessageBox.Show("Order_status Updated Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void O_status_list_Click(object sender, EventArgs e)
        {
             var ds = new DataSet();
            var adpt = new SqlDataAdapter("Select * from Order_status where Order_status_id=" + O_status_list.SelectedValue, conn);
            adpt.Fill(ds, "Order_status");

            foreach (DataRow dr in ds.Tables["Order_status"].Rows)
            
            {
                txtorderstatus_update.Text = dr["Order_status_id"].ToString();
                txtorderid_update.Text = dr["Order_id"].ToString();
                txtProductId_Update.Text = dr["Product_id"].ToString();
            }
            }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Disconnectd_Approach
{
    public partial class Order_Detail : Form
    {
        public Order_Detail()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-B77S1AJ;Initial Catalog=OrderManagmentSystem;Integrated Security=True");
        private void Refreshgridview()
        {
            DataSet ds = new DataSet();
            SqlDataAdapter adpt = new SqlDataAdapter("Select * from Order_Details", conn);

            adpt.Fill(ds, "Order_Details");
            dataGridView1.DataSource = ds.Tables["Order_Details"]; /// yhan tk ki coding load pr display k lie hai

          OrderDetail_List.DataSource = ds.Tables["Order_Details"];
          OrderDetail_List.DisplayMember = "OrderId";
          OrderDetail_List.ValueMember = "OrderId";

            cbOrder_Detail.DataSource = ds.Tables["Order_Details"];
            cbOrder_Detail.DisplayMember = "OrderId";
            cbOrder_Detail.ValueMember = "OrderId";



            DataSet dt = new DataSet();
            SqlDataAdapter dpt = new SqlDataAdapter("Select * from Orders", conn);

            dpt.Fill(dt, "Orders");
            dataGridView2.DataSource = dt.Tables["Orders"]; /// yhan tk ki coding load pr display k lie hai

            DataSet dss = new DataSet();
            SqlDataAdapter aadpt = new SqlDataAdapter("Select * from Product", conn);

            aadpt.Fill(dss, "Product");
            dataGridView3.DataSource = dss.Tables["Product"]; /// yhan tk ki coding load pr display k lie hai
        }

        private void Order_Detail_Load(object sender, EventArgs e)
        {
            Refreshgridview();
            
            DataSet ds = new DataSet();
            SqlDataAdapter adpt = new SqlDataAdapter("Select * from Orders", conn);

            adpt.Fill(ds, "Orders");
            dataGridView2.DataSource = ds.Tables["Orders"]; /// yhan tk ki coding load pr display k lie hai

            DataSet dss = new DataSet();
            SqlDataAdapter aadpt = new SqlDataAdapter("Select * from Product", conn);

            aadpt.Fill(dss, "Product");
            dataGridView3.DataSource = dss.Tables["Product"]; /// yhan tk ki coding load pr display k lie hai
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Resetbutton_Click(object sender, EventArgs e)
        {
            txtOrderId.Text = txtProductId.Text = txtOrderedQuatity.Text = "";
        }

        private void adddetailbutton_Click(object sender, EventArgs e)
        {
            try
            {
                var ds = new DataSet();
                var adpt = new SqlDataAdapter("Select * from Order_Details", conn);
                adpt.Fill(ds, "Order_Details");

                DataRow dr = ds.Tables["Order_Details"].NewRow();

                dr["OrderId"] = txtOrderId.Text;
                dr["ProductId"] = txtProductId.Text;
                dr["OrderQuantity"] = txtOrderedQuatity.Text;

                ds.Tables["Order_Details"].Rows.Add(dr);

                var buil = new SqlCommandBuilder(adpt);
                adpt.Update(ds, "Order_Details");


                Refreshgridview();
                panel_addorder_detail.Visible = false;
                txtOrderId.Text = txtProductId.Text = txtOrderedQuatity.Text = "";
                MessageBox.Show("Order Details Added Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void panel_updateorderdetail_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtorderId_update.Text = txtproductId_update.Text = txtorderquantity_update.Text = "";
        }

        private void orderdetail_updatebutton_Click(object sender, EventArgs e)
        {

            try
            {
                var ds = new DataSet();
                var adpt = new SqlDataAdapter("Select * from Order_Details where OrderId=" + OrderDetail_List.SelectedValue, conn);
                adpt.Fill(ds, "Order_Details");

                foreach (DataRow dr in ds.Tables["Order_Details"].Rows)
                {
                    dr["OrderId"] = txtorderId_update.Text;
                    dr["ProductId"] = txtproductId_update.Text;
                    dr["OrderQuantity"] = txtorderquantity_update.Text;
                }

                var buil = new SqlCommandBuilder(adpt);
                adpt.Update(ds, "Order_Details");

                Refreshgridview();

                MessageBox.Show("Order Details Updated Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void OrderDetail_List_Click(object sender, EventArgs e)
        {
            var ds = new DataSet();
            var adpt = new SqlDataAdapter("Select * from Order_Details where OrderId=" + OrderDetail_List.SelectedValue, conn);
            adpt.Fill(ds, "Order_Details");

            foreach (DataRow dr in ds.Tables["Order_Details"].Rows)
            {
               txtorderId_update.Text = dr["OrderId"].ToString();
               txtproductId_update.Text = dr["ProductId"].ToString();
              txtorderquantity_update.Text = dr["OrderQuantity"].ToString();
                
            }
        }

        private void button2Cancelbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1Deletebutton_Click(object sender, EventArgs e)
        {
            try {
                if (MessageBox.Show("Are you Sure!", "Confirm", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    var ds = new DataSet();
                    var adpt = new SqlDataAdapter("Select * from Order_Details where OrderId=" + cbOrder_Detail.SelectedValue, conn);
                    adpt.Fill(ds, "Order_Details");

                    foreach (DataRow dr in ds.Tables["Order_Details"].Rows)
                    {
                        dr.Delete();
                    }

                    var buil = new SqlCommandBuilder(adpt);
                    adpt.Update(ds, "Order_Details");

                    Refreshgridview();
                    MessageBox.Show("Order Details Deleted Successfully");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtbuttnaddcustomer_Click(object sender, EventArgs e)
        {
            panel_addorder_detail.Visible = true;
            panel_deleteorderdetail.Visible = false;
            panel_updateorderdetail.Visible = false;
        }

        private void Updatebutton_Click(object sender, EventArgs e)
        {
            panel_addorder_detail.Visible = false;
            panel_deleteorderdetail.Visible = false;
            panel_updateorderdetail.Visible = true;
        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {

            panel_addorder_detail.Visible = false;
            panel_deleteorderdetail.Visible = true;
            panel_updateorderdetail.Visible = false;
        }
    }
}

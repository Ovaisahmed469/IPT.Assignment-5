﻿namespace Disconnectd_Approach
{
    partial class Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Deletebutton = new System.Windows.Forms.Button();
            this.Updatebutton = new System.Windows.Forms.Button();
            this.txtbuttnaddcustomer = new System.Windows.Forms.Button();
            this.panel_addproduct = new System.Windows.Forms.Panel();
            this.buttonAddCustomer = new System.Windows.Forms.Button();
            this.Cancelbutton = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtAvailable_Quantity = new System.Windows.Forms.TextBox();
            this.txtProduct_Id = new System.Windows.Forms.TextBox();
            this.txtProduct_Name = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCustomercontact = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtProduct_price = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel_updateproduct = new System.Windows.Forms.Panel();
            this.updatepanelbutton = new System.Windows.Forms.Button();
            this.Resetbutton = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.txtproductquantitiy_update = new System.Windows.Forms.TextBox();
            this.txtproductID_update = new System.Windows.Forms.TextBox();
            this.txtproductname_update = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtproduct_price_update = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Product_List = new System.Windows.Forms.ListBox();
            this.panel_Deleteproduct = new System.Windows.Forms.Panel();
            this.button2Cancelbutton = new System.Windows.Forms.Button();
            this.button1Deletebutton = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.cbproduct_Names = new System.Windows.Forms.ComboBox();
            this.panel_addproduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel_updateproduct.SuspendLayout();
            this.panel_Deleteproduct.SuspendLayout();
            this.SuspendLayout();
            // 
            // Deletebutton
            // 
            this.Deletebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebutton.Location = new System.Drawing.Point(378, 22);
            this.Deletebutton.Name = "Deletebutton";
            this.Deletebutton.Size = new System.Drawing.Size(195, 47);
            this.Deletebutton.TabIndex = 32;
            this.Deletebutton.Text = "Delete";
            this.Deletebutton.UseVisualStyleBackColor = true;
            this.Deletebutton.Click += new System.EventHandler(this.Deletebutton_Click);
            // 
            // Updatebutton
            // 
            this.Updatebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebutton.Location = new System.Drawing.Point(171, 22);
            this.Updatebutton.Name = "Updatebutton";
            this.Updatebutton.Size = new System.Drawing.Size(181, 46);
            this.Updatebutton.TabIndex = 31;
            this.Updatebutton.Text = "Update";
            this.Updatebutton.UseVisualStyleBackColor = true;
            this.Updatebutton.Click += new System.EventHandler(this.Updatebutton_Click);
            // 
            // txtbuttnaddcustomer
            // 
            this.txtbuttnaddcustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbuttnaddcustomer.Location = new System.Drawing.Point(14, 22);
            this.txtbuttnaddcustomer.Name = "txtbuttnaddcustomer";
            this.txtbuttnaddcustomer.Size = new System.Drawing.Size(151, 47);
            this.txtbuttnaddcustomer.TabIndex = 30;
            this.txtbuttnaddcustomer.Text = "Add Product";
            this.txtbuttnaddcustomer.UseVisualStyleBackColor = true;
            this.txtbuttnaddcustomer.Click += new System.EventHandler(this.txtbuttnaddcustomer_Click);
            // 
            // panel_addproduct
            // 
            this.panel_addproduct.BackColor = System.Drawing.Color.Silver;
            this.panel_addproduct.Controls.Add(this.buttonAddCustomer);
            this.panel_addproduct.Controls.Add(this.Cancelbutton);
            this.panel_addproduct.Controls.Add(this.button3);
            this.panel_addproduct.Controls.Add(this.txtAvailable_Quantity);
            this.panel_addproduct.Controls.Add(this.txtProduct_Id);
            this.panel_addproduct.Controls.Add(this.txtProduct_Name);
            this.panel_addproduct.Controls.Add(this.label5);
            this.panel_addproduct.Controls.Add(this.txtCustomercontact);
            this.panel_addproduct.Controls.Add(this.label3);
            this.panel_addproduct.Controls.Add(this.label4);
            this.panel_addproduct.Controls.Add(this.txtProduct_price);
            this.panel_addproduct.Controls.Add(this.label1);
            this.panel_addproduct.Location = new System.Drawing.Point(14, 75);
            this.panel_addproduct.Name = "panel_addproduct";
            this.panel_addproduct.Size = new System.Drawing.Size(730, 339);
            this.panel_addproduct.TabIndex = 33;
            this.panel_addproduct.Visible = false;
            // 
            // buttonAddCustomer
            // 
            this.buttonAddCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddCustomer.Location = new System.Drawing.Point(380, 246);
            this.buttonAddCustomer.Name = "buttonAddCustomer";
            this.buttonAddCustomer.Size = new System.Drawing.Size(128, 51);
            this.buttonAddCustomer.TabIndex = 34;
            this.buttonAddCustomer.Text = "Add ";
            this.buttonAddCustomer.UseVisualStyleBackColor = true;
            this.buttonAddCustomer.Click += new System.EventHandler(this.buttonAddCustomer_Click);
            // 
            // Cancelbutton
            // 
            this.Cancelbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cancelbutton.Location = new System.Drawing.Point(256, 246);
            this.Cancelbutton.Name = "Cancelbutton";
            this.Cancelbutton.Size = new System.Drawing.Size(99, 20);
            this.Cancelbutton.TabIndex = 36;
            this.Cancelbutton.Text = "Cancel";
            this.Cancelbutton.UseVisualStyleBackColor = true;
            this.Cancelbutton.Click += new System.EventHandler(this.Cancelbutton_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(256, 273);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(99, 24);
            this.button3.TabIndex = 35;
            this.button3.Text = "Reset All Box";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtAvailable_Quantity
            // 
            this.txtAvailable_Quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAvailable_Quantity.Location = new System.Drawing.Point(327, 200);
            this.txtAvailable_Quantity.Name = "txtAvailable_Quantity";
            this.txtAvailable_Quantity.Size = new System.Drawing.Size(384, 26);
            this.txtAvailable_Quantity.TabIndex = 33;
            // 
            // txtProduct_Id
            // 
            this.txtProduct_Id.Enabled = false;
            this.txtProduct_Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProduct_Id.Location = new System.Drawing.Point(327, 21);
            this.txtProduct_Id.Name = "txtProduct_Id";
            this.txtProduct_Id.Size = new System.Drawing.Size(382, 26);
            this.txtProduct_Id.TabIndex = 29;
            // 
            // txtProduct_Name
            // 
            this.txtProduct_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProduct_Name.Location = new System.Drawing.Point(327, 79);
            this.txtProduct_Name.Name = "txtProduct_Name";
            this.txtProduct_Name.Size = new System.Drawing.Size(382, 26);
            this.txtProduct_Name.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(5, 14);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 20);
            this.label5.TabIndex = 25;
            this.label5.Text = "Product_Id";
            // 
            // txtCustomercontact
            // 
            this.txtCustomercontact.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomercontact.Location = new System.Drawing.Point(327, 79);
            this.txtCustomercontact.Name = "txtCustomercontact";
            this.txtCustomercontact.Size = new System.Drawing.Size(382, 26);
            this.txtCustomercontact.TabIndex = 31;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 20);
            this.label3.TabIndex = 26;
            this.label3.Text = "Product_Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(5, 206);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 20);
            this.label4.TabIndex = 27;
            this.label4.Text = "Available_Quantity";
            // 
            // txtProduct_price
            // 
            this.txtProduct_price.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProduct_price.Location = new System.Drawing.Point(327, 141);
            this.txtProduct_price.Name = "txtProduct_price";
            this.txtProduct_price.Size = new System.Drawing.Size(382, 26);
            this.txtProduct_price.TabIndex = 32;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 141);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 20);
            this.label1.TabIndex = 28;
            this.label1.Text = "Product_price";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 431);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(679, 150);
            this.dataGridView1.TabIndex = 34;
            // 
            // panel_updateproduct
            // 
            this.panel_updateproduct.BackColor = System.Drawing.Color.Lavender;
            this.panel_updateproduct.Controls.Add(this.updatepanelbutton);
            this.panel_updateproduct.Controls.Add(this.Resetbutton);
            this.panel_updateproduct.Controls.Add(this.buttonCancel);
            this.panel_updateproduct.Controls.Add(this.txtproductquantitiy_update);
            this.panel_updateproduct.Controls.Add(this.txtproductID_update);
            this.panel_updateproduct.Controls.Add(this.txtproductname_update);
            this.panel_updateproduct.Controls.Add(this.label2);
            this.panel_updateproduct.Controls.Add(this.textBox4);
            this.panel_updateproduct.Controls.Add(this.label6);
            this.panel_updateproduct.Controls.Add(this.label7);
            this.panel_updateproduct.Controls.Add(this.txtproduct_price_update);
            this.panel_updateproduct.Controls.Add(this.label8);
            this.panel_updateproduct.Controls.Add(this.Product_List);
            this.panel_updateproduct.Location = new System.Drawing.Point(14, 74);
            this.panel_updateproduct.Name = "panel_updateproduct";
            this.panel_updateproduct.Size = new System.Drawing.Size(962, 351);
            this.panel_updateproduct.TabIndex = 37;
            this.panel_updateproduct.Visible = false;
            // 
            // updatepanelbutton
            // 
            this.updatepanelbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updatepanelbutton.Location = new System.Drawing.Point(607, 243);
            this.updatepanelbutton.Name = "updatepanelbutton";
            this.updatepanelbutton.Size = new System.Drawing.Size(114, 39);
            this.updatepanelbutton.TabIndex = 40;
            this.updatepanelbutton.Text = "Update";
            this.updatepanelbutton.UseVisualStyleBackColor = true;
            this.updatepanelbutton.Click += new System.EventHandler(this.updatepanel_Click);
            // 
            // Resetbutton
            // 
            this.Resetbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Resetbutton.Location = new System.Drawing.Point(482, 270);
            this.Resetbutton.Name = "Resetbutton";
            this.Resetbutton.Size = new System.Drawing.Size(99, 24);
            this.Resetbutton.TabIndex = 39;
            this.Resetbutton.Text = "Reset All Box";
            this.Resetbutton.UseVisualStyleBackColor = true;
            this.Resetbutton.Click += new System.EventHandler(this.Resetbutton_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCancel.Location = new System.Drawing.Point(482, 239);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(99, 24);
            this.buttonCancel.TabIndex = 38;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // txtproductquantitiy_update
            // 
            this.txtproductquantitiy_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtproductquantitiy_update.Location = new System.Drawing.Point(543, 191);
            this.txtproductquantitiy_update.Name = "txtproductquantitiy_update";
            this.txtproductquantitiy_update.Size = new System.Drawing.Size(384, 26);
            this.txtproductquantitiy_update.TabIndex = 37;
            // 
            // txtproductID_update
            // 
            this.txtproductID_update.Enabled = false;
            this.txtproductID_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtproductID_update.Location = new System.Drawing.Point(543, 12);
            this.txtproductID_update.Name = "txtproductID_update";
            this.txtproductID_update.Size = new System.Drawing.Size(382, 26);
            this.txtproductID_update.TabIndex = 33;
            // 
            // txtproductname_update
            // 
            this.txtproductname_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtproductname_update.Location = new System.Drawing.Point(543, 70);
            this.txtproductname_update.Name = "txtproductname_update";
            this.txtproductname_update.Size = new System.Drawing.Size(382, 26);
            this.txtproductname_update.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(290, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 20);
            this.label2.TabIndex = 29;
            this.label2.Text = "Product_Id";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(543, 70);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(382, 26);
            this.textBox4.TabIndex = 35;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(290, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 20);
            this.label6.TabIndex = 30;
            this.label6.Text = "Product_Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(290, 203);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(158, 20);
            this.label7.TabIndex = 31;
            this.label7.Text = "Available_Quantity";
            // 
            // txtproduct_price_update
            // 
            this.txtproduct_price_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtproduct_price_update.Location = new System.Drawing.Point(543, 132);
            this.txtproduct_price_update.Name = "txtproduct_price_update";
            this.txtproduct_price_update.Size = new System.Drawing.Size(382, 26);
            this.txtproduct_price_update.TabIndex = 36;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(290, 138);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 20);
            this.label8.TabIndex = 32;
            this.label8.Text = "Product_price";
            // 
            // Product_List
            // 
            this.Product_List.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Product_List.FormattingEnabled = true;
            this.Product_List.ItemHeight = 31;
            this.Product_List.Location = new System.Drawing.Point(13, 11);
            this.Product_List.Name = "Product_List";
            this.Product_List.Size = new System.Drawing.Size(271, 252);
            this.Product_List.TabIndex = 28;
            this.Product_List.Click += new System.EventHandler(this.Product_List_Click);
            // 
            // panel_Deleteproduct
            // 
            this.panel_Deleteproduct.BackColor = System.Drawing.Color.AliceBlue;
            this.panel_Deleteproduct.Controls.Add(this.button2Cancelbutton);
            this.panel_Deleteproduct.Controls.Add(this.button1Deletebutton);
            this.panel_Deleteproduct.Controls.Add(this.label11);
            this.panel_Deleteproduct.Controls.Add(this.cbproduct_Names);
            this.panel_Deleteproduct.Location = new System.Drawing.Point(14, 81);
            this.panel_Deleteproduct.Name = "panel_Deleteproduct";
            this.panel_Deleteproduct.Size = new System.Drawing.Size(616, 339);
            this.panel_Deleteproduct.TabIndex = 41;
            this.panel_Deleteproduct.Visible = false;
            // 
            // button2Cancelbutton
            // 
            this.button2Cancelbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2Cancelbutton.Location = new System.Drawing.Point(332, 221);
            this.button2Cancelbutton.Name = "button2Cancelbutton";
            this.button2Cancelbutton.Size = new System.Drawing.Size(102, 43);
            this.button2Cancelbutton.TabIndex = 7;
            this.button2Cancelbutton.Text = "Cancel";
            this.button2Cancelbutton.UseVisualStyleBackColor = true;
            // 
            // button1Deletebutton
            // 
            this.button1Deletebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1Deletebutton.Location = new System.Drawing.Point(135, 223);
            this.button1Deletebutton.Name = "button1Deletebutton";
            this.button1Deletebutton.Size = new System.Drawing.Size(96, 41);
            this.button1Deletebutton.TabIndex = 6;
            this.button1Deletebutton.Text = "Delete";
            this.button1Deletebutton.UseVisualStyleBackColor = true;
            this.button1Deletebutton.Click += new System.EventHandler(this.button1Deletebutton_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(73, 62);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(385, 20);
            this.label11.TabIndex = 5;
            this.label11.Text = "Choose The Product what you want to remove.!";
            // 
            // cbproduct_Names
            // 
            this.cbproduct_Names.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbproduct_Names.FormattingEnabled = true;
            this.cbproduct_Names.Location = new System.Drawing.Point(135, 102);
            this.cbproduct_Names.Name = "cbproduct_Names";
            this.cbproduct_Names.Size = new System.Drawing.Size(299, 37);
            this.cbproduct_Names.TabIndex = 4;
            // 
            // Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1074, 593);
            this.Controls.Add(this.panel_updateproduct);
            this.Controls.Add(this.panel_Deleteproduct);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel_addproduct);
            this.Controls.Add(this.Deletebutton);
            this.Controls.Add(this.Updatebutton);
            this.Controls.Add(this.txtbuttnaddcustomer);
            this.Name = "Product";
            this.Text = "Product";
            this.Load += new System.EventHandler(this.Product_Load);
            this.panel_addproduct.ResumeLayout(false);
            this.panel_addproduct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel_updateproduct.ResumeLayout(false);
            this.panel_updateproduct.PerformLayout();
            this.panel_Deleteproduct.ResumeLayout(false);
            this.panel_Deleteproduct.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Deletebutton;
        private System.Windows.Forms.Button Updatebutton;
        private System.Windows.Forms.Button txtbuttnaddcustomer;
        private System.Windows.Forms.Panel panel_addproduct;
        private System.Windows.Forms.TextBox txtAvailable_Quantity;
        private System.Windows.Forms.TextBox txtProduct_Id;
        private System.Windows.Forms.TextBox txtProduct_Name;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCustomercontact;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtProduct_price;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonAddCustomer;
        private System.Windows.Forms.Button Cancelbutton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel_updateproduct;
        private System.Windows.Forms.TextBox txtproductquantitiy_update;
        private System.Windows.Forms.TextBox txtproductID_update;
        private System.Windows.Forms.TextBox txtproductname_update;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtproduct_price_update;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListBox Product_List;
        private System.Windows.Forms.Button updatepanelbutton;
        private System.Windows.Forms.Button Resetbutton;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Panel panel_Deleteproduct;
        private System.Windows.Forms.Button button2Cancelbutton;
        private System.Windows.Forms.Button button1Deletebutton;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cbproduct_Names;

    }
}
﻿namespace Disconnectd_Approach
{
    partial class Order
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Deletebutton = new System.Windows.Forms.Button();
            this.Updatebutton = new System.Windows.Forms.Button();
            this.Addneworderbutton = new System.Windows.Forms.Button();
            this.panel_DeleteOrder = new System.Windows.Forms.Panel();
            this.button2Cancelbutton = new System.Windows.Forms.Button();
            this.button1Deletebutton = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.cb_orderId = new System.Windows.Forms.ComboBox();
            this.panel_UpdateOrder = new System.Windows.Forms.Panel();
            this.txtdateTimePickerupdate = new System.Windows.Forms.DateTimePicker();
            this.txtorderidupdate = new System.Windows.Forms.TextBox();
            this.txtcustomeridupdate = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Order_List = new System.Windows.Forms.ListBox();
            this.update_orderbutton = new System.Windows.Forms.Button();
            this.Resetbutton = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.panel_Addneworder = new System.Windows.Forms.Panel();
            this.buttonAddCustomer = new System.Windows.Forms.Button();
            this.Cancelbutton = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtdateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txtorderid = new System.Windows.Forms.TextBox();
            this.txtCustomerid = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label7 = new System.Windows.Forms.Label();
            this.panel_DeleteOrder.SuspendLayout();
            this.panel_UpdateOrder.SuspendLayout();
            this.panel_Addneworder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // Deletebutton
            // 
            this.Deletebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deletebutton.Location = new System.Drawing.Point(358, 11);
            this.Deletebutton.Name = "Deletebutton";
            this.Deletebutton.Size = new System.Drawing.Size(195, 47);
            this.Deletebutton.TabIndex = 11;
            this.Deletebutton.Text = "Delete";
            this.Deletebutton.UseVisualStyleBackColor = true;
            this.Deletebutton.Click += new System.EventHandler(this.Deletebutton_Click_1);
            // 
            // Updatebutton
            // 
            this.Updatebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Updatebutton.Location = new System.Drawing.Point(171, 12);
            this.Updatebutton.Name = "Updatebutton";
            this.Updatebutton.Size = new System.Drawing.Size(181, 46);
            this.Updatebutton.TabIndex = 10;
            this.Updatebutton.Text = "Update";
            this.Updatebutton.UseVisualStyleBackColor = true;
            this.Updatebutton.Click += new System.EventHandler(this.Updatebutton_Click);
            // 
            // Addneworderbutton
            // 
            this.Addneworderbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addneworderbutton.Location = new System.Drawing.Point(5, 11);
            this.Addneworderbutton.Name = "Addneworderbutton";
            this.Addneworderbutton.Size = new System.Drawing.Size(151, 47);
            this.Addneworderbutton.TabIndex = 9;
            this.Addneworderbutton.Text = "Add New order";
            this.Addneworderbutton.UseVisualStyleBackColor = true;
            this.Addneworderbutton.Click += new System.EventHandler(this.Addneworderbutton_Click);
            // 
            // panel_DeleteOrder
            // 
            this.panel_DeleteOrder.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel_DeleteOrder.Controls.Add(this.button2Cancelbutton);
            this.panel_DeleteOrder.Controls.Add(this.button1Deletebutton);
            this.panel_DeleteOrder.Controls.Add(this.label11);
            this.panel_DeleteOrder.Controls.Add(this.cb_orderId);
            this.panel_DeleteOrder.Location = new System.Drawing.Point(12, 69);
            this.panel_DeleteOrder.Name = "panel_DeleteOrder";
            this.panel_DeleteOrder.Size = new System.Drawing.Size(752, 359);
            this.panel_DeleteOrder.TabIndex = 12;
            this.panel_DeleteOrder.Visible = false;
            this.panel_DeleteOrder.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_DeleteOrder_Paint);
            // 
            // button2Cancelbutton
            // 
            this.button2Cancelbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2Cancelbutton.Location = new System.Drawing.Point(309, 257);
            this.button2Cancelbutton.Name = "button2Cancelbutton";
            this.button2Cancelbutton.Size = new System.Drawing.Size(102, 43);
            this.button2Cancelbutton.TabIndex = 7;
            this.button2Cancelbutton.Text = "Cancel";
            this.button2Cancelbutton.UseVisualStyleBackColor = true;
            this.button2Cancelbutton.Click += new System.EventHandler(this.button2Cancelbutton_Click);
            // 
            // button1Deletebutton
            // 
            this.button1Deletebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1Deletebutton.Location = new System.Drawing.Point(112, 259);
            this.button1Deletebutton.Name = "button1Deletebutton";
            this.button1Deletebutton.Size = new System.Drawing.Size(96, 41);
            this.button1Deletebutton.TabIndex = 6;
            this.button1Deletebutton.Text = "Delete";
            this.button1Deletebutton.UseVisualStyleBackColor = true;
            this.button1Deletebutton.Click += new System.EventHandler(this.button1Deletebutton_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(50, 98);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(375, 20);
            this.label11.TabIndex = 5;
            this.label11.Text = "Choose The Order which you want to remove.!";
            // 
            // cb_orderId
            // 
            this.cb_orderId.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_orderId.FormattingEnabled = true;
            this.cb_orderId.Location = new System.Drawing.Point(112, 138);
            this.cb_orderId.Name = "cb_orderId";
            this.cb_orderId.Size = new System.Drawing.Size(299, 37);
            this.cb_orderId.TabIndex = 4;
            // 
            // panel_UpdateOrder
            // 
            this.panel_UpdateOrder.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel_UpdateOrder.Controls.Add(this.txtdateTimePickerupdate);
            this.panel_UpdateOrder.Controls.Add(this.txtorderidupdate);
            this.panel_UpdateOrder.Controls.Add(this.txtcustomeridupdate);
            this.panel_UpdateOrder.Controls.Add(this.label1);
            this.panel_UpdateOrder.Controls.Add(this.label3);
            this.panel_UpdateOrder.Controls.Add(this.label6);
            this.panel_UpdateOrder.Controls.Add(this.Order_List);
            this.panel_UpdateOrder.Controls.Add(this.update_orderbutton);
            this.panel_UpdateOrder.Controls.Add(this.Resetbutton);
            this.panel_UpdateOrder.Controls.Add(this.buttonCancel);
            this.panel_UpdateOrder.Location = new System.Drawing.Point(5, 66);
            this.panel_UpdateOrder.Name = "panel_UpdateOrder";
            this.panel_UpdateOrder.Size = new System.Drawing.Size(1077, 366);
            this.panel_UpdateOrder.TabIndex = 13;
            this.panel_UpdateOrder.Visible = false;
            this.panel_UpdateOrder.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_UpdateOrder_Paint);
            // 
            // txtdateTimePickerupdate
            // 
            this.txtdateTimePickerupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdateTimePickerupdate.Location = new System.Drawing.Point(417, 153);
            this.txtdateTimePickerupdate.Name = "txtdateTimePickerupdate";
            this.txtdateTimePickerupdate.Size = new System.Drawing.Size(454, 22);
            this.txtdateTimePickerupdate.TabIndex = 47;
            // 
            // txtorderidupdate
            // 
            this.txtorderidupdate.Enabled = false;
            this.txtorderidupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtorderidupdate.Location = new System.Drawing.Point(489, 34);
            this.txtorderidupdate.Name = "txtorderidupdate";
            this.txtorderidupdate.Size = new System.Drawing.Size(382, 22);
            this.txtorderidupdate.TabIndex = 45;
            // 
            // txtcustomeridupdate
            // 
            this.txtcustomeridupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcustomeridupdate.Location = new System.Drawing.Point(489, 94);
            this.txtcustomeridupdate.Name = "txtcustomeridupdate";
            this.txtcustomeridupdate.Size = new System.Drawing.Size(382, 22);
            this.txtcustomeridupdate.TabIndex = 46;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(301, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 16);
            this.label1.TabIndex = 42;
            this.label1.Text = "Order_Id";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(301, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 16);
            this.label3.TabIndex = 43;
            this.label3.Text = "Customer_ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(305, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 16);
            this.label6.TabIndex = 44;
            this.label6.Text = "Order_Date";
            // 
            // Order_List
            // 
            this.Order_List.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Order_List.FormattingEnabled = true;
            this.Order_List.ItemHeight = 31;
            this.Order_List.Location = new System.Drawing.Point(7, 12);
            this.Order_List.Name = "Order_List";
            this.Order_List.Size = new System.Drawing.Size(290, 314);
            this.Order_List.TabIndex = 41;
            this.Order_List.Click += new System.EventHandler(this.Order_List_Click);
            // 
            // update_orderbutton
            // 
            this.update_orderbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.update_orderbutton.Location = new System.Drawing.Point(569, 236);
            this.update_orderbutton.Name = "update_orderbutton";
            this.update_orderbutton.Size = new System.Drawing.Size(114, 39);
            this.update_orderbutton.TabIndex = 40;
            this.update_orderbutton.Text = "Update";
            this.update_orderbutton.UseVisualStyleBackColor = true;
            this.update_orderbutton.Click += new System.EventHandler(this.updatepanel_Click);
            // 
            // Resetbutton
            // 
            this.Resetbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Resetbutton.Location = new System.Drawing.Point(444, 263);
            this.Resetbutton.Name = "Resetbutton";
            this.Resetbutton.Size = new System.Drawing.Size(99, 24);
            this.Resetbutton.TabIndex = 39;
            this.Resetbutton.Text = "Reset All Box";
            this.Resetbutton.UseVisualStyleBackColor = true;
            this.Resetbutton.Click += new System.EventHandler(this.Resetbutton_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCancel.Location = new System.Drawing.Point(444, 232);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(99, 24);
            this.buttonCancel.TabIndex = 38;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // panel_Addneworder
            // 
            this.panel_Addneworder.BackColor = System.Drawing.Color.LightGreen;
            this.panel_Addneworder.Controls.Add(this.buttonAddCustomer);
            this.panel_Addneworder.Controls.Add(this.Cancelbutton);
            this.panel_Addneworder.Controls.Add(this.button3);
            this.panel_Addneworder.Controls.Add(this.txtdateTimePicker1);
            this.panel_Addneworder.Controls.Add(this.txtorderid);
            this.panel_Addneworder.Controls.Add(this.txtCustomerid);
            this.panel_Addneworder.Controls.Add(this.label2);
            this.panel_Addneworder.Controls.Add(this.label5);
            this.panel_Addneworder.Controls.Add(this.label4);
            this.panel_Addneworder.Location = new System.Drawing.Point(12, 64);
            this.panel_Addneworder.Name = "panel_Addneworder";
            this.panel_Addneworder.Size = new System.Drawing.Size(845, 361);
            this.panel_Addneworder.TabIndex = 42;
            this.panel_Addneworder.Visible = false;
            this.panel_Addneworder.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_Addneworder_Paint);
            // 
            // buttonAddCustomer
            // 
            this.buttonAddCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddCustomer.Location = new System.Drawing.Point(441, 198);
            this.buttonAddCustomer.Name = "buttonAddCustomer";
            this.buttonAddCustomer.Size = new System.Drawing.Size(128, 51);
            this.buttonAddCustomer.TabIndex = 19;
            this.buttonAddCustomer.Text = "Add ";
            this.buttonAddCustomer.UseVisualStyleBackColor = true;
            this.buttonAddCustomer.Click += new System.EventHandler(this.buttonAddCustomer_Click);
            // 
            // Cancelbutton
            // 
            this.Cancelbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cancelbutton.Location = new System.Drawing.Point(317, 198);
            this.Cancelbutton.Name = "Cancelbutton";
            this.Cancelbutton.Size = new System.Drawing.Size(99, 20);
            this.Cancelbutton.TabIndex = 29;
            this.Cancelbutton.Text = "Cancel";
            this.Cancelbutton.UseVisualStyleBackColor = true;
            this.Cancelbutton.Click += new System.EventHandler(this.Cancelbutton_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(317, 225);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(99, 24);
            this.button3.TabIndex = 28;
            this.button3.Text = "Reset All Box";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // txtdateTimePicker1
            // 
            this.txtdateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdateTimePicker1.Location = new System.Drawing.Point(275, 128);
            this.txtdateTimePicker1.Name = "txtdateTimePicker1";
            this.txtdateTimePicker1.Size = new System.Drawing.Size(454, 22);
            this.txtdateTimePicker1.TabIndex = 27;
            // 
            // txtorderid
            // 
            this.txtorderid.Enabled = false;
            this.txtorderid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtorderid.Location = new System.Drawing.Point(347, 9);
            this.txtorderid.Name = "txtorderid";
            this.txtorderid.Size = new System.Drawing.Size(382, 22);
            this.txtorderid.TabIndex = 23;
            // 
            // txtCustomerid
            // 
            this.txtCustomerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerid.Location = new System.Drawing.Point(347, 69);
            this.txtCustomerid.Name = "txtCustomerid";
            this.txtCustomerid.Size = new System.Drawing.Size(382, 22);
            this.txtCustomerid.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 16);
            this.label2.TabIndex = 17;
            this.label2.Text = "Order_Id";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 16);
            this.label5.TabIndex = 18;
            this.label5.Text = "Customer_ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(11, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 16);
            this.label4.TabIndex = 21;
            this.label4.Text = "Order_Date";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(22, 481);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(415, 142);
            this.dataGridView1.TabIndex = 43;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.Click += new System.EventHandler(this.dataGridView1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(92, 447);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 20);
            this.label8.TabIndex = 44;
            this.label8.Text = "Orders Table";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(464, 481);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(393, 142);
            this.dataGridView2.TabIndex = 45;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(490, 447);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(144, 20);
            this.label7.TabIndex = 44;
            this.label7.Text = "Customers Table";
            // 
            // Order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1094, 626);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel_Addneworder);
            this.Controls.Add(this.panel_UpdateOrder);
            this.Controls.Add(this.panel_DeleteOrder);
            this.Controls.Add(this.Deletebutton);
            this.Controls.Add(this.Updatebutton);
            this.Controls.Add(this.Addneworderbutton);
            this.Name = "Order";
            this.Text = "Order";
            this.Load += new System.EventHandler(this.Order_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Order_Paint);
            this.panel_DeleteOrder.ResumeLayout(false);
            this.panel_DeleteOrder.PerformLayout();
            this.panel_UpdateOrder.ResumeLayout(false);
            this.panel_UpdateOrder.PerformLayout();
            this.panel_Addneworder.ResumeLayout(false);
            this.panel_Addneworder.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Deletebutton;
        private System.Windows.Forms.Button Updatebutton;
        private System.Windows.Forms.Button Addneworderbutton;
        private System.Windows.Forms.Panel panel_DeleteOrder;
        private System.Windows.Forms.Button button2Cancelbutton;
        private System.Windows.Forms.Button button1Deletebutton;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cb_orderId;
        private System.Windows.Forms.Panel panel_UpdateOrder;
        private System.Windows.Forms.ListBox Order_List;
        private System.Windows.Forms.Button update_orderbutton;
        private System.Windows.Forms.Button Resetbutton;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Panel panel_Addneworder;
        private System.Windows.Forms.Button buttonAddCustomer;
        private System.Windows.Forms.Button Cancelbutton;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DateTimePicker txtdateTimePicker1;
        private System.Windows.Forms.TextBox txtorderid;
        private System.Windows.Forms.TextBox txtCustomerid;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker txtdateTimePickerupdate;
        private System.Windows.Forms.TextBox txtorderidupdate;
        private System.Windows.Forms.TextBox txtcustomeridupdate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label7;
    }
}
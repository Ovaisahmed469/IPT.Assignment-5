﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Disconnectd_Approach
{
    public partial class Productdetail : Form
    {
        public Productdetail()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (StreamReader sr = new StreamReader("D:\\COMP SCI LAB\\NED CLASSES\\ADO.NET Disconnected  Appproach\\Disconnectd Approach\\Disconnectd Approach\\pro_detail.txt"))
            {
                while (!sr.EndOfStream)
                {
                    richTextBox1.AppendText(sr.ReadLine());
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (StreamWriter wr = new StreamWriter("D:\\COMP SCI LAB\\NED CLASSES\\ADO.NET Disconnected  Appproach\\Disconnectd Approach\\Disconnectd Approach\\pro_detail.txt"))
            {
                wr.WriteLine(richTextBox1.Text);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }
    }
}

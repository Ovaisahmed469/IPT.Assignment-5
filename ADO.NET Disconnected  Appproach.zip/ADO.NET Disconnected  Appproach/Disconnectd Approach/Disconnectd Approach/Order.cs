﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Disconnectd_Approach
{
    public partial class Order : Form
    {
        public Order()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-B77S1AJ;Initial Catalog=OrderManagmentSystem;Integrated Security=True");

         private void Refreshgridview()
        { 
             DataSet ds = new DataSet();
            SqlDataAdapter adpt = new SqlDataAdapter("Select * from Orders", conn);
            adpt.Fill(ds, "Orders");
            dataGridView1.DataSource = ds.Tables["Orders"];

            Order_List.DataSource = ds.Tables["Orders"];
            Order_List.DisplayMember = "Id";
            Order_List.ValueMember = "Id";

            cb_orderId.DataSource = ds.Tables["Orders"];
            cb_orderId.DisplayMember = "Id";
            cb_orderId.ValueMember = "Id";
        }


        private void Addneworderbutton_Click(object sender, EventArgs e)
        {
            panel_Addneworder.Visible = true;
            panel_DeleteOrder.Visible = false;
            panel_UpdateOrder.Visible = false;
        }

        private void Updatebutton_Click(object sender, EventArgs e)
        {
            panel_Addneworder.Visible = false;
            panel_DeleteOrder.Visible = false;
            panel_UpdateOrder.Visible = true;
        }

        private void button1Deletebutton_Click(object sender, EventArgs e)
        {

            try
            {

            
            if (MessageBox.Show("Are you Sure!", "Confirm", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                var ds = new DataSet();
                var adpt = new SqlDataAdapter("Select * from Orders where Id=" +  cb_orderId.SelectedValue, conn);
                adpt.Fill(ds, "Orders");

                foreach (DataRow dr in ds.Tables["Orders"].Rows)
                {
                    dr.Delete();
                }

                var buil = new SqlCommandBuilder(adpt);
                adpt.Update(ds, "Orders");

                Refreshgridview();
                MessageBox.Show("Order  Deleted Successfully");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Cancelbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtCustomerid.Text = txtorderid.Text = "";
            txtdateTimePicker1.Value = System.DateTime.Now;
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Resetbutton_Click(object sender, EventArgs e)
        {
            txtcustomeridupdate.Text = txtorderidupdate.Text = "";
            txtdateTimePickerupdate.Value = System.DateTime.Now;
        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            panel_Addneworder.Visible = false;
            panel_DeleteOrder.Visible = true;
            panel_UpdateOrder.Visible = false;
        }

        private void Deletebutton_Click_1(object sender, EventArgs e)
        {
            panel_Addneworder.Visible = false;
            panel_DeleteOrder.Visible = true;
            panel_UpdateOrder.Visible = false;
        }

        private void Order_Load(object sender, EventArgs e)
        {
            Refreshgridview();

            DataSet ds = new DataSet();
            SqlDataAdapter adpt = new SqlDataAdapter("Select * from Customer", conn);

            adpt.Fill(ds, "Customer");
            dataGridView2.DataSource = ds.Tables["Customer"]; /// yhan tk ki coding load pr display k lie hai
        }

        private void buttonAddCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                var ds = new DataSet();
                var adpt = new SqlDataAdapter("Select * from Orders", conn);
                adpt.Fill(ds, "Orders");

                DataRow dr = ds.Tables["Orders"].NewRow();


                dr["CustomerId"] = txtCustomerid.Text;
                dr["OrderDate"] = txtdateTimePicker1.Value;

                ds.Tables["Orders"].Rows.Add(dr);

                var buil = new SqlCommandBuilder(adpt);
                adpt.Update(ds, "Orders");


                Refreshgridview();
                panel_Addneworder.Visible = false;
                update_orderbutton.Enabled = true;
                txtCustomerid.Text = "";
                txtdateTimePicker1.Value = System.DateTime.Now;
                MessageBox.Show("Order Added Successfully");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void updatepanel_Click(object sender, EventArgs e)
        {
            try
            {
                update_orderbutton.Enabled = true;

                var ds = new DataSet();
                var adpt = new SqlDataAdapter("Select * from Orders where Id=" + Order_List.SelectedValue, conn);
                adpt.Fill(ds, "Orders");

                foreach (DataRow dr in ds.Tables["Orders"].Rows)
                {

                    dr["CustomerId"] = txtcustomeridupdate.Text;
                    dr["OrderDate"] = txtdateTimePickerupdate.Text;

                }

                var buil = new SqlCommandBuilder(adpt);
                adpt.Update(ds, "Orders");

                Refreshgridview();

                MessageBox.Show("Order Updated Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Order_List_Click(object sender, EventArgs e)
        {
            var ds = new DataSet();
            var adpt = new SqlDataAdapter("Select * from Orders where Id=" + Order_List.SelectedValue, conn);
            adpt.Fill(ds, "Orders");

            foreach (DataRow dr in ds.Tables["Orders"].Rows)
            {
                txtorderidupdate.Text = dr["Id"].ToString();
            txtcustomeridupdate.Text = dr["CustomerId"].ToString();
              txtdateTimePickerupdate.Text = dr["OrderDate"].ToString();
                //txtdateTimePicker1update.Value = Convert.ToDateTime(dr["DOB"]);
            }
        }

        private void button2Cancelbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel_Addneworder_Paint(object sender, PaintEventArgs e)
        {
            panel_UpdateOrder.Visible = false;
        }

        private void panel_UpdateOrder_Paint(object sender, PaintEventArgs e)
        {
            panel_Addneworder.Visible = false;
            panel_DeleteOrder.Visible = false;
        }

        private void panel_DeleteOrder_Paint(object sender, PaintEventArgs e)
        {
            panel_Addneworder.Visible = false;
            panel_UpdateOrder.Visible= false;
            
        }

        private void Order_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

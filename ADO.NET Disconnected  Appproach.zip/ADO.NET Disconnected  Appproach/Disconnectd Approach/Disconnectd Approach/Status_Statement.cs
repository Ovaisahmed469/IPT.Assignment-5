﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Disconnectd_Approach
{
    public partial class Status_Statement : Form
    {
        public Status_Statement()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-B77S1AJ;Initial Catalog=OrderManagmentSystem;Integrated Security=True");

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Status_Statement_Load(object sender, EventArgs e)
        {
            Refreshgridview();


            bool autosave = false;
            string name = "Recieved";
            if (txtorder_statusid.Text != " ")
            {
                autosave = true;
            }
            if (autosave == true)
            {
                txt_statement.Text = name;
            }
            else
            {
                Console.ReadLine();
            }
        }

        private void Refreshgridview()
        {
            DataSet ds = new DataSet();
            SqlDataAdapter adpt = new SqlDataAdapter("Select * from Order_status", conn);
            adpt.Fill(ds, "Order_status");
            dataGridView1.DataSource = ds.Tables["Order_status"];



            DataSet dt = new DataSet();
            SqlDataAdapter dpt = new SqlDataAdapter("Select * from Status_statement", conn);
            dpt.Fill(dt, "Status_statement");



            listBox1.DataSource = dt.Tables["Status_statement"];
            listBox1.DisplayMember = "statement_id";
            listBox1.ValueMember = "statement_id";

            comboBox1.DataSource = dt.Tables["Status_statement"];
            comboBox1.DisplayMember = "statement_id";
            comboBox1.ValueMember = "statement_id";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void deletebutton_Click(object sender, EventArgs e)
        {
            try
            {


                if (MessageBox.Show("Are you Sure!", "Confirm", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    var ds = new DataSet();
                    var adpt = new SqlDataAdapter("Select * from Status_statement where statement_id=" + comboBox1.SelectedValue, conn);
                    adpt.Fill(ds, "Status_statement");

                    foreach (DataRow dr in ds.Tables["Status_statement"].Rows)
                    {
                        dr.Delete();
                    }

                    var buil = new SqlCommandBuilder(adpt);
                    adpt.Update(ds, "Status_statement");

                    Refreshgridview();
                    MessageBox.Show("Status_statement  Deleted Successfully");
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void addorderstatus_Click(object sender, EventArgs e)
        {
            try
            {
                var ds = new DataSet();
                var adpt = new SqlDataAdapter("Select * from Status_statement", conn);
                adpt.Fill(ds, "Status_statement");

                DataRow dr = ds.Tables["Status_statement"].NewRow();


                dr["order_status_id"] = txtorder_statusid.Text;
                dr["Statement"] = txt_statement.Text;

                ds.Tables["Status_statement"].Rows.Add(dr);

                var buil = new SqlCommandBuilder(adpt);
                adpt.Update(ds, "Status_statement");


                Refreshgridview();
                txt_statement.Text = txtorder_statusid.Text = "";
                MessageBox.Show("Status_statement Added Successfully");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public void button3_Click(object sender, EventArgs e)
        {
            try
            {


                var ds = new DataSet();
                var adpt = new SqlDataAdapter("Select * from Status_statement where statement_id=" + listBox1.SelectedValue, conn);
                adpt.Fill(ds, "Status_statement");

                foreach (DataRow dr in ds.Tables["Status_statement"].Rows)
                {
                    dr["order_status_id"] = txtorder_statusid_update.Text;
                    dr["Statement"] = txt_statement_update.Text;

                }

                var buil = new SqlCommandBuilder(adpt);
                adpt.Update(ds, "Status_statement");

                Refreshgridview();

                MessageBox.Show("Status_statement Updated Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void listBox1_Click(object sender, EventArgs e)
        {
            var ds = new DataSet();
            var adpt = new SqlDataAdapter("Select * from Status_statement where statement_id =" + listBox1.SelectedValue, conn);
            adpt.Fill(ds, "Status_statement");

            foreach (DataRow dr in ds.Tables["Status_statement"].Rows)
            {
                txtstatementid_update.Text = dr["statement_id"].ToString();
                txtorder_statusid_update.Text = dr["order_status_id"].ToString();
                txt_statement_update.Text = dr["Statement"].ToString();
            }
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Disconnectd_Approach
{
    public partial class Status_Report : Form
    {
        public Status_Report()
        {
            InitializeComponent();
        }

        private void Status_Report_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'OrderManagmentSystemDataSet1.Status_Report' table. You can move, or remove it, as needed.
            this.Status_ReportTableAdapter.Fill(this.OrderManagmentSystemDataSet1.Status_Report);

            this.reportViewer1.RefreshReport();
        }
    }
}

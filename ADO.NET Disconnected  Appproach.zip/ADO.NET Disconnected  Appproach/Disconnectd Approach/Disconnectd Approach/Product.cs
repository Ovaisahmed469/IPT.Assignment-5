﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Disconnectd_Approach
{
    public partial class Product : Form
    {
        public Product()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-B77S1AJ;Initial Catalog=OrderManagmentSystem;Integrated Security=True");

        private void Cancelbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtAvailable_Quantity.Text = txtProduct_price.Text = txtProduct_Name.Text = txtProduct_Id.Text = "";
        }

        private void txtbuttnaddcustomer_Click(object sender, EventArgs e)
        {
            panel_addproduct.Visible = true;
            panel_Deleteproduct.Visible = false;
            panel_updateproduct.Visible = false;
        }

        private void buttonAddCustomer_Click(object sender, EventArgs e)
        {
            try
            {

                var ds = new DataSet();
                var adpt = new SqlDataAdapter("Select * from Product", conn);
                adpt.Fill(ds, "Product");

                DataRow dr = ds.Tables["Product"].NewRow();
                dr["Name"] = txtProduct_Name.Text;
                dr["Price"] = txtProduct_price.Text;
                dr["AvalaibleQuantity"] = txtAvailable_Quantity.Text;

                ds.Tables["Product"].Rows.Add(dr);

                var buil = new SqlCommandBuilder(adpt);
                adpt.Update(ds, "Product");


                Refreshgridview();
                panel_addproduct.Visible = false;

                txtProduct_Name.Text = txtProduct_price.Text = txtAvailable_Quantity.Text = "";

                MessageBox.Show("Product Added Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Resetbutton_Click(object sender, EventArgs e)
        {
            txtproduct_price_update.Text = txtproductquantitiy_update.Text = txtproductname_update.Text = txtproductID_update.Text = "";
        }

        private void Updatebutton_Click(object sender, EventArgs e)
        {
            panel_updateproduct.Visible = true;
            panel_addproduct.Visible = false;
            panel_Deleteproduct.Visible = false;
        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            panel_Deleteproduct.Visible = true;
            panel_addproduct.Visible = false;
            panel_updateproduct.Visible = false;
        }

        private void Product_Load(object sender, EventArgs e)
        {
            Refreshgridview();
        }
        private void Refreshgridview()
        {
            DataSet ds = new DataSet();
            SqlDataAdapter adpt = new SqlDataAdapter("Select * from Product", conn);

            adpt.Fill(ds, "Product");
            dataGridView1.DataSource = ds.Tables["Product"];

            Product_List.DataSource = ds.Tables["Product"];
            Product_List.DisplayMember = "Name";
            Product_List.ValueMember = "Id";

            cbproduct_Names.DataSource = ds.Tables["Product"];
            cbproduct_Names.DisplayMember = "Name";
            cbproduct_Names.ValueMember = "Id";
        }

        private void button1Deletebutton_Click(object sender, EventArgs e)
        {
            try {
                if (MessageBox.Show("Are you Sure!", "Confirm", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    var ds = new DataSet();
                    var adpt = new SqlDataAdapter("Select * from Product where Id=" + cbproduct_Names.SelectedValue, conn);
                    adpt.Fill(ds, "Product");

                    foreach (DataRow dr in ds.Tables["Product"].Rows)
                    {
                        dr.Delete();
                    }

                    var buil = new SqlCommandBuilder(adpt);
                    adpt.Update(ds, "Product");

                    Refreshgridview();
                    MessageBox.Show(" Product  Deleted Successfully");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Product_List_Click(object sender, EventArgs e)
        {
            var ds = new DataSet();
            var adpt = new SqlDataAdapter("Select * from Product where Id=" + Product_List.SelectedValue, conn);
            adpt.Fill(ds, "Product");

            foreach (DataRow dr in ds.Tables["Product"].Rows)
            {
               txtproductID_update.Text = dr["Id"].ToString();
                txtproductname_update.Text = dr["Name"].ToString();
                txtproduct_price_update.Text = dr["Price"].ToString();
                txtproductquantitiy_update.Text = dr["AvalaibleQuantity"].ToString();
            }
        }

        private void updatepanel_Click(object sender, EventArgs e)
        {
            try
            {
                updatepanelbutton.Enabled = true;

                var ds = new DataSet();
                var adpt = new SqlDataAdapter("Select * from Product where Id=" + Product_List.SelectedValue, conn);
                adpt.Fill(ds, "Product");

                foreach (DataRow dr in ds.Tables["Product"].Rows)
                {
                    dr["Id"] = txtproductID_update.Text;
                    dr["Name"] = txtproductname_update.Text;
                    dr["Price"] = txtproduct_price_update.Text;
                    dr["AvalaibleQuantity"] = txtproductquantitiy_update.Text;
                }

                var buil = new SqlCommandBuilder(adpt);
                adpt.Update(ds, "Product");

                Refreshgridview();

                MessageBox.Show("Product Updated Successfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
